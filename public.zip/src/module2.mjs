import a, {b, c, d} from './module1.mjs'

console.log(a);
console.log(b);