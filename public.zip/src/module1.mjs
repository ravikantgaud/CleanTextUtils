const a = 'Ravikant';
const b = 'Ganesh';
const c = 'Suresh';
const d = 'Mahesh';

export default a;
export {b};
export {c};
export {d};